
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import itertools
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.metrics import accuracy_score, confusion_matrix


# In[2]:


#Read the data
df=pd.read_csv('C:\\Users\\ADMIN\\Downloads\\news\\news.csv')

#Get shape and head
df.shape
df.head()


# In[3]:


labels=df.label
labels.head()


# In[4]:


x_train,x_test,y_train,y_test=train_test_split(df['text'], labels, test_size=0.2, random_state=7)


# In[5]:


# Initialize a TfidfVectorizer
tfidf_vectorizer=TfidfVectorizer(stop_words='english', max_df=0.7)

#Fit and transform train set, transform test set
tfidf_train=tfidf_vectorizer.fit_transform(x_train) 
tfidf_test=tfidf_vectorizer.transform(x_test)


# In[6]:


from sklearn.neighbors import KNeighborsClassifier


# In[7]:


from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.svm import SVC
from sklearn import model_selection


# In[30]:


clf = SVC()


# In[ ]:


clf.fit(tfidf_train,y_train)


# In[22]:


clf.predict(tfidf_test)


# In[ ]:


y_pred=clf.predict(tfidf_test)
score = accuracy_score(y_pred,y_test)


# In[ ]:


print('Accuracy with SVM: ')
score*100


# In[8]:


clf2= DecisionTreeClassifier()


# In[9]:


clf2.fit(tfidf_train,y_train)


# In[10]:


y_pred2 = clf2.predict(tfidf_test)
Score_dtree = accuracy_score(y_pred2,y_test)
print('Accuracy with Decesion Tree: ')
Score_dtree*100


# In[11]:


clf3 = KNeighborsClassifier(n_neighbors=5)


# In[12]:


clf3.fit(tfidf_train,y_train)


# In[13]:


y_pred3 = clf3.predict(tfidf_test)
Score_kNN = accuracy_score(y_pred3,y_test)
print('Accuracy with KNN: ')
Score_kNN*100


# In[14]:


clf4 = LogisticRegression()


# In[15]:


clf4.fit(tfidf_train,y_train)


# In[16]:


y_pred4 = clf4.predict(tfidf_test)
Score_LR = accuracy_score(y_pred4,y_test)
print('Accuracy with Logistic Regretion: ')
Score_LR*100


# In[26]:


confusion_matrix(y_test,y_pred2, labels=['FAKE','REAL'])


# In[28]:


confusion_matrix(y_test,y_pred3, labels=['FAKE','REAL'])


# In[29]:


confusion_matrix(y_test,y_pred4, labels=['FAKE','REAL'])

